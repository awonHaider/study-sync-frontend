import { useState } from "react";
import { FaGoogle, FaFacebookF, FaApple } from "react-icons/fa";

import "./App.css";
import SignUpPage from "./Pages/SignUpPage";
import SignInPage from "./Pages/SignInPage";
import Layout from "./Layout";
import Homepage from "./Pages/Homepage";
function App() {
  return (
    <SignUpPage></SignUpPage>
    // <SignInPage />
    // <Layout>
    //   <Homepage></Homepage>
    // </Layout>
  );
}

export default App;
