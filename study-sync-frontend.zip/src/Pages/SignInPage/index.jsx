import React from 'react'
import { FaGoogle, FaFacebookF, FaApple } from "react-icons/fa";
import { FaEyeSlash } from "react-icons/fa6";


const SignInPage = () => {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-blue-50 to-blue-100">
      <div className="absolute top-8 left-8 text-lg font-bold text-gray-800">
        <span className="bg-gray-200 rounded-full px-2 py-1 text-sm">📦</span> Ebolt
      </div>

      <div className="w-full max-w-md p-6 bg-white rounded-3xl shadow-lg">
        {/* Icon */}
        <div className="flex justify-center mb-3">
          <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-xl">
            <span>🔐</span>
          </div>
        </div>

        {/* Title */}
        <h2 className="text-lg font-semibold text-center mb-1">Sign in with email</h2>
        <p className="text-center text-gray-500 mb-4 text-xs md:text-sm">
          Make a new doc to bring your words, data, and teams together. For free.
        </p>

        {/* Form */}
        <form className="space-y-3">
          <div>
            <input
              type="email"
              placeholder="Email"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 text-sm"
            />
          </div>
          <div className="relative">
            <input
              type="password"
              placeholder="Password"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 text-sm"
            />
            <button
              type="button"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              <FaEyeSlash/>
            </button>
          </div>
          <div className="flex justify-end text-xs">
            <a href="#" className="text-blue-500 hover:underline">
              Forgot password?
            </a>
          </div>
          <button
            type="submit"
            className="w-full py-2 mt-3 bg-black text-white rounded-lg hover:bg-gray-800 text-sm"
          >
            Get Started
          </button>
        </form>

        {/* Divider */}
        <div className="flex items-center justify-center mt-4">
          <span className="text-gray-400 text-xs">Or sign in with</span>
        </div>

        {/* Social Buttons */}
        <div className="flex justify-center gap-3 mt-3">
          <button className="p-2 bg-gray-100 rounded-full hover:bg-gray-200">
            <FaGoogle className="text-base" />
          </button>
          <button className="p-2 bg-gray-100 rounded-full hover:bg-gray-200">
            <FaFacebookF className="text-base text-blue-600" />
          </button>
          <button className="p-2 bg-gray-100 rounded-full hover:bg-gray-200">
            <FaApple className="text-base" />
          </button>
        </div>
      </div>
    </div>
  );
}

export default SignInPage;
