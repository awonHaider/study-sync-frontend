import React from "react";
import mainSectionImage from "../../Images/Homepage/mainSectionImage.png";
import mainSectionImageTwo from "../../Images/Homepage/mainSectionImageTwo.png";
import mainSectionImageThree from "../../Images/Homepage/mainSectionImageThree.png";
import callOptionIcons from "../../Images/Homepage/callOptionIcons.png";
import signalIcon from "../../Images/Homepage/signalIcon.png";

const Homepage = () => {
  return (
    // First Section - Power of Peer to Peer
    <>
      <section>
        <div className="container mx-auto px-3 md:px-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Left section takes 2/3 on larger screens and full width on smaller screens */}
            <div className="col-span-1 md:col-span-2 bg-[#EFEFEF] rounded-xl p-5 flex flex-col gap-11 md:gap-[7rem]">
              <div className="flex flex-col gap-5">
                <div>
                  <h2 className="font-[500] text-center md:text-left text-3xl md:text-4xl">
                    Unlock the Power of Peer-to-Peer
                  </h2>
                  <h2 className="font-[500] text-center md:text-left text-3xl md:text-4xl ">
                    Learning
                  </h2>
                </div>
                <p className="text-[#8A8A8A] md:text-xl text-center md:text-left ">
                  Comprehensive peer-to-peer study platform designed to enhance
                  <span className="block">
                    {" "}
                    collaborative learning among students
                  </span>
                </p>
                <button className=" self-center md:self-start text-white bg-[#006BDE] px-6 py-2 rounded-full w-[9rem]">
                  Try For Free
                </button>
              </div>

              <div className="flex flex-col md:flex-row gap-3 items-center justify-center md:justify-start">
                <img
                  src="src\Images\Homepage\usersMiniIcons.png"
                  alt=""
                  className="h-6"
                />
                <p className="text-[#666666] ">3M + students worldwide</p>
              </div>
            </div>

            {/* Right section takes full width on smaller screens */}
            <div className="col-span-1 md:col-span-1  rounded-xl overflow-hidden relative">
              <img
                src={mainSectionImage}
                alt="Main section image"
                className=" object-cover object-top w-full h-[250px] md:h-full"
              />

              <img
                className="absolute bottom-3 left-[3rem] md:left-[4.5rem]"
                src={callOptionIcons}
                alt="Call Option Icons"
              />

              <img
                className="absolute top-3 right-3"
                src={signalIcon}
                alt="Call Option Icons"
              />
            </div>
          </div>
        </div>
      </section>
      {/* Second Section - Two Images */}
      <section>
        <div className="container mx-auto px-3 md:px-12 mt-4">
          <div className="grid md:grid-cols-2 gap-3">
            <div className=" rounded-xl overflow-hidden relative">
              <img
                src={mainSectionImageTwo}
                alt="Main section image"
                className=" object-cover w-full h-[250px] md:h-[400px]"
              />

              <img
                className="absolute top-3 right-3"
                src={signalIcon}
                alt="Call Option Icons"
              />
            </div>
            <div className=" rounded-xl overflow-hidden relative">
              <img
                src={mainSectionImageThree}
                alt="Main section image"
                className=" object-cover w-full h-[250px] md:h-[400px]"
              />

              <img
                className="absolute top-3 right-3"
                src={signalIcon}
                alt="Call Option Icons"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Third Section - Why Choose StudySync? */}
      <section>
        <div className="container mx-auto px-3 md:px-12 mt-16">
          <div className="grid grid-cols-10">
            <div className="col-span-10 md:col-span-4 flex flex-col gap-5 md:pr-8 mt-3">
              <h3 className="text-2xl md:text-3xl text-center md:text-left font-semibold">
                Why Choose StudySync?
              </h3>
              <p className="text-center md:text-left md:text-lg text-[#8A8A8A] tracking-wider">
                Comprehensive peer-to-peer study platform designed to enhance
                collaborative learning among students
              </p>
              <div className="text-[#8A8A8A] font-[500] tracking-wider flex flex-col gap-1 md:gap-3 text-center md:text-left">
                <div className="px-2 py-1 md:py-2 hover:border-l-4 border-[#006BDE] hover:text-[#000] t">
                  <p>Seamless Collaboration</p>
                </div>

                <div className="px-2 py-1 md:py-2 hover:border-l-4 border-[#006BDE] hover:text-[#000]">
                  <p>Video Conferencing</p>
                </div>

                <div className="px-2 py-1 md:py-2 hover:border-l-4 border-[#006BDE] hover:text-[#000]">
                  <p>Real Time Chat</p>
                </div>

                <div className="px-2 py-1 md:py-2 hover:border-l-4 border-[#006BDE] hover:text-[#000]">
                  <p>Interactive Whiteboard</p>
                </div>

                <div className="px-2 py-1 md:py-2 hover:border-l-4 border-[#006BDE] hover:text-[#000]">
                  <p>Resource Sharing</p>
                </div>
              </div>
            </div>
            <div className="col-span-10 md:col-span-6 bg-[#EFEFEF] h-50 rounded-xl"></div>
          </div>
        </div>
      </section>

      {/* Fourth Section - Number Section */}
      <section>
        <div className="container mx-auto">
          <div className="flex justify-center">
            <div className="grid grid-cols-3 w-[80%] mt-14 text-center">
              <div>
                <h4 className="text-[3.3rem] font-[500]">200k+</h4>
                <p className="text-[#8A8A8A] text-lg tracking-wider">
                  Registered Students
                </p>
              </div>
              <div>
                <h4 className="text-[3.3rem] font-[500]">50+</h4>
                <p className="text-[#8A8A8A] text-lg tracking-wider">
                  Universities Globally
                </p>
              </div>
              <div>
                <h4 className="text-[3.3rem] font-[500]">20bp</h4>
                <p className="text-[#8A8A8A] text-lg tracking-wider">
                  Data Served
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Homepage;
