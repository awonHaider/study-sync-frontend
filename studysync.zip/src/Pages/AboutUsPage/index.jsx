import React from "react";
import aboutUsImageOne from "../../Images/AboutUspage/aboutUsImageOne.png";
import aboutUsImageTwo from "../../Images/AboutUspage/aboutUsImageTwo.png";
import aboutUsImageThree from "../../Images/AboutUspage/aboutUsImageThree.png";
import aboutUsFormBG from "../../Images/AboutUspage/aboutUsFormBG.png";

const AboutUsPage = () => {
  return (
    <>
      {/* First Section - About Us */}
      <section className="mt-10">
        <div className="container mx-auto">
          <div className="flex flex-col items-center gap-3 max-w-xl mx-auto">
            <h2 className="text-4xl font-[600]">About Us</h2>
            <p className="text-[#8A8A8A] text-lg text-center">
              Lorem ipsum dolor sit amet consectetur. Pulvinar dolor nunc
              volutpat risus scelerisque arcu.
            </p>
            <div className="flex flex-col md:flex-row gap-3 items-center justify-center md:justify-start mt-4">
              <img
                src="src\Images\Homepage\usersMiniIcons.png"
                alt=""
                className="h-6"
              />
              <p className="text-[#666666] ">3M + students worldwide</p>
            </div>
          </div>
        </div>
      </section>

      {/* Second Section - Our Values */}
      <section className="my-14 ">
        <div className="container mx-auto">
          <div className="grid grid-cols-10 max-w-5xl mx-auto ">
            {/* left side - images */}
            <div className=" col-span-7 relative h-[400px]">
              <div className="w-[330px] ">
                <img className="w-full" src={aboutUsImageOne} alt="" />
              </div>

              <div className="w-[330px] absolute left-[18rem] top-[7rem]">
                <img className="w-full" src={aboutUsImageTwo} alt="" />
              </div>
            </div>
            {/* right side - Text */}
            <div className=" col-span-3 h-[100%] py-16">
              <div className="p-4 flex flex-col gap-4">
                <h3 className=" font-semibold text-gray-500">Our Values</h3>
                <h2 className="text-2xl font-bold text-gray-900 ">
                  Lorem ipsum dolor sit amet consectetur. Feugiat vitae ut
                  feugiat amet pellentesque.
                </h2>
                <p className="text-gray-500 ">
                  Lorem ipsum dolor sit amet consectetur. Pulvinar dolor nunc
                  volutpat risus scelerisque arcu.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Third Section - Grow and Connect*/}
      <section className="my-14 ">
        <div className="container mx-auto">
          <div
            className="grid grid-cols-10 max-w-6xl mx-auto bg-cover bg-center"
            style={{ backgroundImage: `url(${aboutUsFormBG})` }}
          >
            {/* left side - form */}
            <div className=" col-span-6 px-10">
              <section className=" py-20">
                <div className="container mx-auto max-w-4xl px-4">
                  {/* Heading and Text */}
                  <div className="mb-6">
                    <h2 className="text-2xl font-bold text-gray-900">
                      Grow and Connect with us
                    </h2>
                    <p className="text-[#8A8A8A] mt-2">
                      Lorem ipsum dolor sit amet consectetur. Pulvinar dolor
                      nunc volutpat risus scelerisque arcu.
                    </p>
                  </div>
                  {/* Input and Button */}
                  <form className="flex items-center space-x-4">
                    <input
                      type="email"
                      placeholder="Enter your email here ...."
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      type="submit"
                      className="px-6 py-3 bg-[#006BDE] text-white font-medium rounded-md hover:bg-blue-600 transition"
                    >
                      Submit
                    </button>
                  </form>
                </div>
              </section>
            </div>
            {/* right side - image */}
            <div className=" col-span-4 py-10 pl-20">
              <div className="w-[300px] ">
                <img className="w-full" src={aboutUsImageOne} alt="" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutUsPage;
